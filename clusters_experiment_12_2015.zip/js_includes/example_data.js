var shuffleSequence = seq("intro", sepWith("sep",  seq("practice")), "practiceover", sepWith("sep", rshuffle(startsWith("exp"), startsWith("f"))));

var continueMessage = ["Klikni zde"];

var aj = "AcceptabilityJudgment";

var q = "Question";

var completionMessage = "[Zadané odpovědi jsou odeslány na server. Děkujeme za spolupráci!]";

var ms = "Message";

var defaults = [    
    "Separator", { transfer: 800,
                   normalMessage: "Počkejte prosím na další položku v experimentu.",
                   errorMessage: "Špatně. Počkejte prosím na další položku v experimentu." 
         },
    "AcceptabilityJudgment", { as: [["a", "Ano"], ["n", "Ne"]],
                               randomOrder: false,
                               showNumbers: false,
                               },
    "Message", { hideProgressBar: true, transfer: "click" }
];

var progressBarText = "";

var items = [ ["sep", "Separator", { }],

          ["intro", "Form", {continueMessage: "Pro vstup do experimentu, klikněte zde", html: { include: "example_intro.html" }}],

          ["practice", aj, {s: {html: "<div style=\"text-align: center\";\"width: 30em;\"><img src=\"https://sites.google.com/site/mojmirdocekal/experiment_12_2015/practice_items/practice_1.png?attredirects=0\" width: 200px></div><div style=\"text-align: center\"; font-size=\"+3\"><p><font size=\"+2\">Na obrázku je více klíčů než kaštanů.</font></p><i>Je věta pravdivá?</i></div>"}}],
["practice", aj, {s: {html: "<div style=\"width: 30em;\"><img src=\"http://www.jakubdotlacil.com/cl-brno/practice_images/practice_2.png\"></div><div style=\"text-align: center\"; font-size=\"+3\"><p><font size=\"+2\">Na obrázku je stejný počet klíčů jako kaštanů.</font></p><i>Je věta pravdivá?</i></div>"}}],
["practice", aj, {s: {html: "<div style=\"width: 30em;\"><img src=\"http://www.jakubdotlacil.com/cl-brno/practice_images/practice_3.png\"></div><div style=\"text-align: center\"; font-size=\"+3\"><p><font size=\"+2\">Na obrázku je třikrát tolik kaštanů jako klíčů.</font></p><i>Je věta pravdivá?</i></div>"}}],

          ["practiceover", "Message", {continueMessage: "Klikněte zde pro pokračování experimentu", html: ["div", ["p", "Zde končí přípravná část experimentu. Klikněte níže pro vstup do experimentu."]]}],

[["exp-item1-overlap-dvoje", 1], aj, {s: {html: "<div style=\"width: 40em;\"><img src=\"http://www.jakubdotlacil.com/cl-brno/A_dvoje/hora-overlap_v2.png\"></div><div style=\"text-align: center\"; font-size=\"+3\"><p><font size=\"+2\">V horních rozích jsou dvoje hory.</font></p><i>Je věta pravdivá?</i></div>"}}],
[["exp-item1-overlap-skupiny", 1], aj, {s: {html: "<div style=\"width: 40em;\"><img src=\"http://www.jakubdotlacil.com/cl-brno/A_dvoje/hora-overlap_v2.png\"></div><div style=\"text-align: center\"; font-size=\"+3\"><p><font size=\"+2\">V horních rozích jsou dvě skupiny hor.</font></p><i>Je věta pravdivá?</i></div>"}}],
    [["exp-item1-spread-dvoje", 1], aj, {s: {html: "<div style=\"width: 40em;\"><img src=\"http://www.jakubdotlacil.com/cl-brno/A_dvoje/hora-spread.png\"></div><div style=\"text-align: center\"; font-size=\"+3\"><p><font size=\"+2\">Podél okrajů jsou dvoje hory.</font></p><i>Je věta pravdivá?</i></div>"}}],
    [["exp-item1-spread-skupiny", 1], aj, {s: {html: "<div style=\"width: 40em;\"><img src=\"http://www.jakubdotlacil.com/cl-brno/A_dvoje/hora-spread.png\"></div><div style=\"text-align: center\"; font-size=\"+3\"><p><font size=\"+2\">Podél okrajů jsou dvě skupiny hor.</font></p><i>Je věta pravdivá?</i></div>"}}],

["filler1", aj, {s: {html: "<div style=\"width: 40em;\"><img src=\"http://www.jakubdotlacil.com/cl-brno/filler_A.png\"></div><div style=\"text-align: center\"; font-size=\"+3\"><p><font size=\"+2\">Na obrázku je nejvíc klíčů.</font></p><i>Je věta pravdivá?</i></div>"}}]

];
